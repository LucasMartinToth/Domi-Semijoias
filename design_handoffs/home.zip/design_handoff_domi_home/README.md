# Handoff: Domi — Home (telas 2a desktop / 2b mobile, versão lorem)

## Overview
Home de e-commerce da **Domi** (semijoias, São Paulo). O pacote entrega as telas **2b (mobile, 390px — base do design)** e **2a (desktop, 1440px — adaptação)** na versão **wireframe de conteúdo**: toda a copy é *lorem ipsum* e as fotos são placeholders listrados. Estrutura, hierarquia, espaçamento, cores, tipografia e interações são finais; apenas texto e imagens são substituíveis.

O fluxo coberto: faixa de anúncio → header (navegação, busca, conta, carrinho) → hero full-bleed → banner de coleção destaque → grid de categorias → barra de benefícios (4 ícones) → grid de produtos → bloco social/Instagram → bloco "processo" (fundo escuro) → rodapé com newsletter. Mais três overlays: dropdown de coleções, menu lateral mobile, gaveta de carrinho e modal de busca mobile.

## About the Design Files
Os arquivos deste bundle são **referências de design feitas em HTML** — protótipos que mostram aparência e comportamento pretendidos, **não código de produção para copiar**. A tarefa é **recriar estes designs no ambiente já existente do codebase** (React, Vue, SwiftUI, nativo, etc.), usando seus padrões, componentes e bibliotecas. Se ainda não houver ambiente definido, escolha o framework mais adequado ao projeto e implemente lá.

O protótipo usa um runtime próprio (`support.js`, template + classe de lógica). **Não porte esse runtime.** Leia-o como especificação: markup = estrutura, `class Component` = estado e handlers.

## Fidelity
**Hi-fi em layout e estilo / lo-fi em conteúdo.**
- Cores, tipografia, espaçamentos, tamanhos, estados e animações são finais → reproduzir com precisão.
- Textos (*lorem ipsum*) e imagens (placeholders listrados) são substituíveis → receberão copy e fotos reais da marca.

## Screens / Views

### 2b — Mobile (390px) — tela base
Larguras/paddings pensados para 390px; o desktop é adaptação desta lógica.

| Bloco | Layout |
|---|---|
| Faixa de anúncio | altura auto, `padding: 8px 12px`, `background: #96695e`, texto `#f6f2ee`, 9.5px, `letter-spacing: .16em`, uppercase, centralizado |
| Header (sticky, `top: 0`, z-index 30) | altura 58px, `padding: 0 10px`, `grid-template-columns: 44px 1fr 44px`; fundo `rgba(236,233,229,.94)` + `backdrop-filter: blur(12px)`; borda inferior `1px solid rgba(150,105,94,.18)` |
| Hamburguer | botão 44×44, três traços `width:100%; height:1px; background:#2b201c`, `gap: 5px` |
| Logo | 92×28.5px, `Domi.svg` como máscara sobre `#96695e` |
| Carrinho | botão 44×44, ícone 20px stroke 1.3, badge 15×15 `border-radius:999px`, `#96695e`/`#f6f2ee`, 9px, canto sup. dir. (`top:5px; right:3px`) |
| Hero | `height: 520px`, placeholder listrado + gradiente `to top` do bg opaco (0–26%) ao transparente (84%); conteúdo ancorado embaixo (`padding: 0 22px 30px`, `gap: 16px`): eyebrow 10px/`.24em`/uppercase `#96695e`, H1 serif 40px/1.05 `#96695e`, parágrafo 14px/1.65 `#5d4b44` weight 300, dois CTAs empilhados (`display: grid; gap: 10px`) |
| CTA primário | full width, `padding: 17px`, `#2b201c` sobre `#ece9e5`, 11px/`.18em`/uppercase |
| CTA secundário | full width, `padding: 15px`, borda `1px solid rgba(43,32,28,.28)`, texto `#2b201c` |
| Banner coleção destaque | `height: 470px`, listras `#8b6055`/`#815549` (10px), gradiente `to top` de `#96695e` (0–30%) a transparente (80%); conteúdo embaixo: eyebrow 10px `rgba(246,242,238,.85)`, H2 serif 34px/1.05, parágrafo 13.5px, CTA full width `#f6f2ee` sobre texto `#96695e` |
| Barra de benefícios | `grid-template-columns: 1fr 1fr`, cada célula `padding: 20px 18px`, `gap: 7px`, bordas `1px solid rgba(150,105,94,.14)` (top+left); ícone SVG 22px stroke 1.3 `#96695e`, título 10px/`.18em`/uppercase, texto 11.5px/1.55 `#6b574f` |
| Grid de produtos | `padding: 34px 22px 0`; header da seção (eyebrow 10px + H2 serif 30px + link "ver tudo" 10px com `border-bottom`); grid `1fr 1fr`, `gap: 22px 14px` |
| Card de produto | imagem `aspect-ratio: 4/5`; tag opcional `top:10px; left:10px`, `#ece9e5`/`#96695e`, 9px/`.14em`, `padding: 4px 7px`; nome 12.5px, material 10.5px `#8b7a72` w300, preço 12.5px `#96695e` |
| Bloco social | `padding: 34px 22px`, eyebrow 10px, H2 serif 30px `#96695e` (@handle), parágrafo 13.5px, grid `1fr 1fr 1fr` `gap: 8px` de quadrados `aspect-ratio: 1`, CTA full width `#96695e`/`#f6f2ee` com ícone 16px |
| Bloco processo (escuro) | `background: #2b201c`, `padding: 38px 22px`, `gap: 18px`; eyebrow `#c9a99f`, H2 serif 30px `#ece9e5`, dois placeholders `aspect-ratio: 1` em listras `#3a2c26`/`#33251f`, parágrafo `rgba(236,233,229,.72)`; três métricas (serif 26px `#ece9e5` + label 9.5px `#c9a99f`), `border-top: 1px solid rgba(236,233,229,.18)` |
| Rodapé | `background: #2b201c`, `padding: 34px 22px 26px`, `gap: 22px`; logo 92px invertido (`filter: invert(1) brightness(.94)`); 4 botões sociais 44×44 com borda `rgba(236,233,229,.28)`; bloco newsletter (label 10px `#c9a99f`, input transparente `padding: 15px`, botão `#96695e` `padding: 16px`); colunas de links empilhadas em `flex-wrap` `gap: 8px 18px`; base legal 10.5px |

### 2a — Desktop (1440px) — adaptação
Mesma ordem de blocos, mesma paleta e tipografia; muda a densidade.

| Bloco | Diferenças |
|---|---|
| Faixa de anúncio | 11px/`.18em`, `padding: 9px 16px` |
| Header (sticky) | altura 76px, container `max-width: 1360px; padding: 0 40px`, `grid-template-columns: 1fr auto 1fr`; nav à esquerda (`gap: 28px`, 11.5px/`.16em`/uppercase `#4a3a34`, hover `#96695e`), logo central 118×36.6px `#96695e`, ícones à direita (`gap: 20px`, 19px stroke 1.3) |
| Hero | full-bleed, `min-height: 620px`; grid `1fr 1.08fr` dentro de `max-width: 1360px`; placeholder cobre a seção inteira em `position: absolute; inset: 0`; gradiente **linear 100deg**: `#ece9e5` 0–30% → `rgba(…,.82)` 46% → `rgba(…,.32)` 66% → transparente 82%; coluna de texto `padding: 96px 64px 96px 0`, `gap: 26px`; H1 serif 62px/1.04, `letter-spacing: -.01em`; CTAs lado a lado (`flex; gap: 14px`) — primário `padding: 16px 34px`, secundário só com `border-bottom` |
| Banner coleção destaque | seção `background: #96695e`, `overflow: hidden`, grid `1fr 1fr` **sem container centralizado**: a coluna de texto usa `padding-left: max(40px, calc((100% * 2 - 1360px) / 2 + 40px))` para alinhar à grade, e a foto **sangra até a borda direita** (`height: 560px`, listras 12px `#8b6055`/`#815549`) |
| Categorias | `max-width: 1360px; padding: 0 40px`, grid `repeat(4, 1fr)` `gap: 16px`; cada card `height: 300px`, título serif 30px `#f6f2ee` sobre gradiente `to top rgba(43,32,28,.55)`, link "explorar" 10.5px/`.2em` |
| Barra de benefícios | seção full-bleed com `border-top`/`border-bottom` `rgba(150,105,94,.18)`; grid `repeat(4, 1fr)`, células centralizadas `padding: 8px 24px`, ícone 26px, título 11px/`.2em`, texto 12.5px `max-width: 210px` |
| Grid de produtos | `padding: 72px 40px 0`; cabeçalho em `space-between` (H2 serif 44px); grid `repeat(4, 1fr)` `gap: 20px`; card igual ao mobile em proporção, nome 13.5px, material 11.5px, preço 13px |
| Bloco social | `padding: 80px 40px`; cabeçalho em `space-between` com CTA sólido `#96695e` (`padding: 16px 30px`, ícone 17px); grid `repeat(6, 1fr)` `gap: 14px` de quadrados |
| Bloco processo (escuro) | seção `background: #2b201c`, container `padding: 88px 40px`, grid `1.1fr 1fr` `gap: 64px`; à esquerda dois quadrados (`1fr 1fr`, `gap: 16px`, o segundo com `margin-top: 36px`); à direita H2 serif 42px `#ece9e5` + parágrafo `max-width: 440px` + três métricas serif 32px em `grid-template-columns: repeat(3, auto)` `gap: 32px` |
| Rodapé | grid `1.5fr 1fr 1fr 1fr 1.4fr` `gap: 48px`, `padding: 68px 40px 34px`; coluna 1 = logo + descrição + 4 sociais 32×32; colunas 2–4 = listas de links 12.5px; coluna 5 = newsletter (input + botão `#96695e` inline); barra inferior `border-top: 1px solid rgba(236,233,229,.14)`, `padding: 22px 40px 40px`, 11px em `space-between` |

## Sistema de placeholders de imagem (importante)
**Nenhuma imagem real é usada.** Todo slot de foto é uma `<div>`/`<span>` com listras diagonais CSS:

```css
background: repeating-linear-gradient(135deg, <tomA> 0 12px, <tomB> 12px 24px);
```

- **Passo das listras:** `12px` no desktop, `10px` no mobile (mantém a densidade visual parecida entre as duas escalas). Ângulo sempre `135deg`.
- **Pares de tons por contexto:**
  - Produto / detalhe / social (fundo claro): `#e2dcd7` → `#dad3cd`
  - Hero: `#ddd6d0` → `#d5cdc6`
  - Bloco escuro "processo": `#3a2c26` → `#33251f`
  - Banner Moissanite (fundo marca): `#8b6055` → `#815549`
- **Legenda do slot:** originalmente cada placeholder trazia um `<span>` em `position: absolute` (cantos: `top/left: 12px` ou `bottom/left: 12px`; 10px desktop / 9px mobile) em `font-family: ui-monospace, monospace`, cor `#6f5f57` em fundos claros e `rgba(236,233,229,.6)` em fundos escuros, descrevendo o conteúdo esperado e as dimensões — ex. `foto · colar · 330×300`, `produto 01`, `post 01`, `still de coleção · moissanite · 720×880`, `foto editorial · hero full-bleed · 2880×1120`. **Nas telas 2a/2b desta entrega esses spans foram removidos** (wireframe limpo), mas o mapa de dimensões acima é a referência de recorte para as fotos reais.
- **Origem das legendas no protótipo:** vinham de dados na lógica — `products[].slot`, `categories[].slot`, `instaSlots` — e não de markup fixo; ou seja, o número de slots é data-driven (8 produtos, 4 categorias, 6 posts).
- **Proporção:** definida por `aspect-ratio` (`4/5` cards de produto, `1/1` grade social e detalhes) ou por `height` fixo (hero 520px mobile / seção 620px desktop, banner 470px mobile / 560px desktop, card de categoria 300px). **Nunca** por dimensões da imagem.
- **Como trocar por fotos reais:** substituir a propriedade `background` pelo `background-image: url(<foto>)` com `background-size: cover; background-position: center` (e remover a legenda, se ainda existir). Nada mais muda: `aspect-ratio`/`height`, gradientes de leitura por cima e posicionamento dos textos continuam válidos. Em produção, usar `<img>` com `object-fit: cover` dentro do mesmo box também funciona — o placeholder listrado pode ficar como `background` de fallback/skeleton de carregamento.

## Interactions & Behavior

**Dropdown de coleções (desktop)** — clique no item "Coleções" alterna um painel `position: absolute; top: 28px; left: -20px; min-width: 236px`, `background: #ece9e5`, borda `rgba(150,105,94,.22)`, `box-shadow: 0 24px 48px rgba(43,32,28,.16)`, itens `padding: 12px 20px` 11px/`.14em`/uppercase, hover `background: rgba(150,105,94,.1)`, cor `#96695e`. Fecha ao escolher um item. Itens: 3 coleções.

**Busca desktop** — clique na lupa expande um input inline (`width: 240px`, só `border-bottom: 1px solid rgba(150,105,94,.5)`) à esquerda do ícone. Ao digitar, aparece uma lista de resultados abaixo (mesmo estilo do dropdown, filtro `includes` case-insensitive sobre a lista de produtos). Vazio = sem lista.

**Menu de conta (desktop)** — clique no ícone de usuário abre painel `top: 32px; right: -8px; min-width: 196px` com saudação (10px/`.18em`/uppercase `#96695e`, `border-bottom`) e 4 itens de conta.

**Exclusividade dos overlays** — abrir dropdown, busca, conta ou carrinho fecha os outros três (um único `only(key)` no estado).

**Gaveta de carrinho (desktop)** — overlay `rgba(43,32,28,.45)` (clique fecha) + painel de `420px` alinhado à direita, cabeçalho com título serif 26px `#96695e` e botão de fechar, lista rolável, rodapé fixo com Subtotal / Frete / Total (serif 26px `#96695e`) e CTA "finalizar" `#2b201c` + link "continuar comprando".
- Linha do carrinho: grid `76px 1fr auto`, thumb `aspect-ratio: 4/5`, stepper `− qty +` (botões 28×28 dentro de borda `rgba(150,105,94,.3)`), botão "remover" 10.5px/`.14em`/uppercase `#96695e` com `border-bottom`.
- Regras: `qty` mínimo 1 no decremento; remover exclui a linha; badge do header mostra a soma das quantidades; **frete grátis acima de R$ 299**, senão R$ 29; total = subtotal (+ frete quando aplicável); carrinho vazio mostra mensagem de estado vazio.

**Menu lateral mobile** — hamburguer abre overlay `rgba(43,32,28,.5)` (fade `domiFadeIn` .2s ease-out) + painel de `300px` deslizando da esquerda: `@keyframes domiSlideIn { from { transform: translateX(-100%) } to { translateX(0) } }`, `.28s cubic-bezier(.22,.61,.36,1)`. Conteúdo: cabeçalho com logo + fechar; grupo "coleções" (itens serif 22px); grupo "categorias" (12.5px/`.14em`/uppercase); rodapé fixo com "Minha conta" e "Buscar" (linhas de 44px com ícone 17px). Qualquer item fecha o menu; "Buscar" fecha o menu e abre o modal de busca.

**Gaveta de carrinho mobile** — mesmo conteúdo e regras da desktop, painel de `340px` deslizando da direita (`@keyframes domiSlideRight`), thumb 62px, stepper com botões 32×32 (alvo de toque), preço na mesma linha do nome com `white-space: nowrap`.

**Modal de busca mobile** — sobrepõe o menu (z-index maior). Folha branca no topo da tela: barra com lupa 18px `#96695e`, input 15px, botão fechar 44×44; sem query mostra "buscas populares" como chips (`border: 1px solid rgba(150,105,94,.3)`, `padding: 11px 14px`, 12px); com query mostra resultados como linhas de 44px com thumb 40×50 listrada.

**Alvos de toque** — todo controle mobile tem ao menos 44×44px.

**Hover (desktop)** — links de nav e rodapé vão para `#96695e` / `#ece9e5`; CTA escuro → `#96695e`; CTA claro → `#96695e` com texto claro; itens de dropdown ganham fundo `rgba(150,105,94,.1)`.

## State Management
Estado único no topo da página:
- `colsOpen`, `searchOpen`, `userOpen`, `cartOpen` — overlays desktop (mutuamente exclusivos).
- `menuOpen`, `mCartOpen`, `mSearchOpen` — overlays mobile (menu e carrinho exclusivos; busca sobrepõe).
- `query` — string da busca; derivados: `hasHits` (query não vazia), `searchHits` (filtro sobre nomes de produto), `noQuery` (mostra buscas populares).
- `cart: [{ id, name, material, price, qty }]` — derivados: `cartCount` (soma de `qty`), `subtotal`, `shipping` (0 se subtotal ≥ 299, senão 29), `total`, `cartEmpty`.
- Ações: `toggle*`/`close*` por overlay, `closeAll`, `inc`/`dec`/`remove` por linha do carrinho.

Sem fetch: os dados (produtos, categorias, coleções, posts, links de rodapé) são listas estáticas — na integração viram chamadas de catálogo/carrinho da plataforma.

## Design Tokens

**Cores**
| Token | Hex | Uso |
|---|---|---|
| Marca | `#96695e` | títulos, eyebrows, preços, banner destaque, botões, badges |
| Fundo | `#ece9e5` | fundo geral, texto sobre escuro |
| Tinta escura | `#2b201c` | texto principal, CTA primário, bloco escuro, rodapé |
| Claro sobre marca | `#f6f2ee` | texto sobre `#96695e` |
| Texto secundário | `#5d4b44` | parágrafos |
| Texto terciário | `#6b574f` | apoios curtos |
| Texto sutil | `#8b7a72` | material do produto |
| Nav / ícones | `#4a3a34` | itens de menu, ícones |
| Rosé claro | `#c9a99f` | labels sobre fundo escuro |
| Listras | `#e2dcd7`/`#dad3cd`, `#ddd6d0`/`#d5cdc6`, `#3a2c26`/`#33251f`, `#8b6055`/`#815549` | placeholders |
| Fundo do canvas | `#dedad5` | só a mesa de apresentação, não é do site |

Transparências recorrentes: `rgba(150,105,94,.14/.16/.18/.22/.28/.3/.5)` (bordas em fundo claro), `rgba(236,233,229,.14/.18/.28/.6/.72)` (bordas/texto em fundo escuro), `rgba(43,32,28,.45/.5/.55)` (overlays), `rgba(43,32,28,.16/.18/.3/.32)` (sombras).

**Tipografia**
- Display/títulos: **TAN Twinkle**, fallback `EB Garamond`, Georgia, serif — weight 400. Escala: 62 / 50 / 44 / 42 / 34 / 30 / 26 / 23 / 22px.
- UI/texto: **Inter** (300/400/500). Escala: 15 / 14 / 13.5 / 13 / 12.5 / 11.5 / 11 / 10.5 / 10 / 9.5px.
- Monospace (legendas de placeholder): `ui-monospace, monospace`, 9–12px.
- Padrão de label: uppercase + `letter-spacing` `.14em`–`.28em` (quanto menor a fonte, maior o tracking).
- `line-height`: 1.04–1.15 em títulos, 1.55–1.75 em parágrafos.

**Espaçamento** — múltiplos de 2/4: gaps 6, 8, 10, 12, 14, 16, 18, 20, 22, 26, 28, 32, 48, 64px. Padding de seção: mobile 22px lateral / 34–38px vertical; desktop 40px lateral / 68–96px vertical. Container desktop: `max-width: 1360px`.

**Raios** — 0 em tudo (estética editorial), exceto `border-radius: 999px` nos badges de contagem.

**Sombras** — `0 24px 48px rgba(43,32,28,.16)` (dropdowns), `-30px 0 80px rgba(43,32,28,.3)` / `30px 0 70px rgba(43,32,28,.3)` (gavetas), `0 30px 70px rgba(43,32,28,.32)` (modal de busca). A sombra `0 30px 80px rgba(43,32,28,.18)` nos quadros 2a/2b é da apresentação, não do site.

**Animações** — `domiFadeIn` (opacity 0→1, .2–.22s ease-out) e `domiSlideIn` / `domiSlideRight` (translateX ∓100%→0, .28s `cubic-bezier(.22,.61,.36,1)`).

## Assets
- `Domi.svg` — logotipo, incluído no bundle. Aplicado como **máscara CSS** (`-webkit-mask`/`mask: url(Domi.svg) center/contain no-repeat`) sobre `background: #96695e` no header, para colorir na cor da marca; no rodapé é usado como `<img>` com `filter: invert(1) brightness(.94)` para virar claro sobre fundo escuro. Em produção, prefira duas variantes do SVG (marca e clara) em vez do filtro.
- Ícones: SVGs inline desenhados no protótipo (lupa, usuário, sacola, gota/banho, caminhão, setas de troca, cartão, Instagram, fechar, chevron), `stroke-width: 1.2–1.4`, `stroke-linecap: round`, `currentColor`. Substituir pelo icon set do codebase mantendo peso de traço fino e tamanho 17–26px.
- Fontes: **TAN Twinkle** precisa ser licenciada e hospedada pelo cliente (o protótipo cai em `EB Garamond` via Google Fonts). **Inter** via Google Fonts (300–600).
- Nenhuma foto: ver "Sistema de placeholders de imagem".

## Files
- `Domi Wireframe Lorem.dc.html` — telas **2a** (desktop) e **2b** (mobile) desta entrega, lado a lado no mesmo canvas. Markup = estrutura/estilo; `class Component` no fim do arquivo = estado e handlers.
- `Domi Home.dc.html` — a mesma home com a **copy real** em português (1a desktop / 1b mobile) e as legendas dos placeholders visíveis. Útil como referência de conteúdo e de tamanho de texto por bloco.
- `support.js` — runtime do protótipo. **Não portar**; presente apenas para os arquivos abrirem no navegador.
- `Domi.svg` — logotipo.
